# Conexión OpenAI
