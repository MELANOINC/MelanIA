# Lógica IA con OpenAI
