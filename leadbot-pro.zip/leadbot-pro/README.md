# LeadBot PRO MELANO INC

**Cómo usar:**

1. Copia backend/.env.example a backend/.env y pon tus claves
2. Inicializa la base de datos:
   docker-compose run backend python -c "from app.services.db import Base, engine; Base.metadata.create_all(bind=engine)"
3. Levanta todo:
   docker-compose up --build
4. Abre frontend/index.html en tu navegador
5. (En producción cambia API_URL en script.js al endpoint real)
